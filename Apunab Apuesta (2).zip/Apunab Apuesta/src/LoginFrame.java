// LoginFrame.java (actualizado para pasar el nombre al Dashboard)
// LoginFrame.java (actualizado para pasar el nombre al Dashboard)
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Scanner;

public class LoginFrame extends JFrame {
    private JTextField emailField;
    private JPasswordField passwordField;
    private JCheckBox rememberMeCheck;

    public LoginFrame() {
        setTitle("Apunab - Login");
        setSize(420, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel logoLabel = new JLabel();
        logoLabel.setBounds(140, 20, 120, 120); 
        add(logoLabel);

        JLabel title = new JLabel("Apunab : Apuesta por tu Futuro");
        title.setFont(new Font("SansSerif", Font.BOLD, 16));
        title.setBounds(80, 150, 300, 30);
        add(title);

        emailField = new JTextField();
        emailField.setBounds(60, 200, 300, 35);
        emailField.setBorder(BorderFactory.createTitledBorder("Email o tel�fono"));
        add(emailField);

        passwordField = new JPasswordField();
        passwordField.setBounds(60, 250, 300, 35);
        passwordField.setBorder(BorderFactory.createTitledBorder("Contrase�a"));
        add(passwordField);

        rememberMeCheck = new JCheckBox("Recordarme");
        rememberMeCheck.setBounds(60, 300, 120, 20);
        rememberMeCheck.setBackground(Color.WHITE);
        add(rememberMeCheck);

        JButton loginBtn = new JButton("Iniciar sesi�n");
        loginBtn.setBounds(60, 340, 300, 40);
        loginBtn.setBackground(new Color(10, 102, 255));
        loginBtn.setForeground(Color.WHITE);
        add(loginBtn);

        JButton signupBtn = new JButton("Reg�strate aqu�");
        signupBtn.setBounds(230, 435, 130, 30);
        signupBtn.setFocusPainted(false);
        signupBtn.setContentAreaFilled(false);
        signupBtn.setForeground(Color.BLUE);
        add(signupBtn);

        loginBtn.addActionListener(e -> {
            String email = emailField.getText();
            String pass = new String(passwordField.getPassword());
            boolean found = false;
            String nombreUsuario = "";

            try {
                Scanner sc = new Scanner(new File("usuarios.txt"));
                while (sc.hasNextLine()) {
                    String[] parts = sc.nextLine().split(",");
                    if (parts.length == 4) {
                        String userEmail = parts[0];
                        String userPass = parts[3];

                        if (userEmail.equals(email) && userPass.equals(pass)) {
                            found = true;
                            nombreUsuario = parts[2];
                            break;
                        }
                    }
                }
                sc.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(this, "No se encontr� el archivo de usuarios");
            }

            if (found) {
                JOptionPane.showMessageDialog(this, "Inicio de sesi�n exitoso");
                new DashboardFrame(nombreUsuario); // Aseguramos pasar nombre
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Correo o contrase�a incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        signupBtn.addActionListener(e -> {
            new RegisterFrame();
            dispose();
        });

        setVisible(true);
    }
}
