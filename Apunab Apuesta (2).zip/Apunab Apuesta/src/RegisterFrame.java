import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class RegisterFrame extends JFrame {
    private JTextField nameField, emailField, phoneField;
    private JPasswordField passwordField, confirmPasswordField;

    public RegisterFrame() {
        setTitle("Apunab - Registro");
        setSize(450, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        // Imagen institucional
        JLabel imageLabel = new JLabel();
        imageLabel.setBounds(150, 20, 150, 100); 
        // imageLabel.setIcon(new ImageIcon("src/assets/unab_logo.png"));
        add(imageLabel);

        JLabel title = new JLabel("Crea tu cuenta");
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        title.setBounds(150, 130, 200, 30);
        add(title);

        nameField = new JTextField();
        nameField.setBounds(60, 180, 320, 35);
        nameField.setBorder(BorderFactory.createTitledBorder("Nombre completo"));
        add(nameField);

        emailField = new JTextField();
        emailField.setBounds(60, 230, 320, 35);
        emailField.setBorder(BorderFactory.createTitledBorder("Correo institucional"));
        add(emailField);

        phoneField = new JTextField();
        phoneField.setBounds(60, 280, 320, 35);
        phoneField.setBorder(BorderFactory.createTitledBorder("N�mero de tel�fono"));
        add(phoneField);

        passwordField = new JPasswordField();
        passwordField.setBounds(60, 330, 320, 35);
        passwordField.setBorder(BorderFactory.createTitledBorder("Contrase�a"));
        add(passwordField);

        confirmPasswordField = new JPasswordField();
        confirmPasswordField.setBounds(60, 380, 320, 35);
        confirmPasswordField.setBorder(BorderFactory.createTitledBorder("Confirmar contrase�a"));
        add(confirmPasswordField);

        JButton registerBtn = new JButton("Registrar");
        registerBtn.setBounds(60, 440, 320, 40);
        registerBtn.setBackground(new Color(10, 102, 255));
        registerBtn.setForeground(Color.WHITE);
        add(registerBtn);

        JButton backBtn = new JButton("�Ya tienes cuenta? Inicia sesi�n");
        backBtn.setBounds(120, 490, 200, 30);
        backBtn.setFocusPainted(false);
        backBtn.setContentAreaFilled(false);
        backBtn.setForeground(Color.BLUE);
        add(backBtn);

        // Acci�n de registro
        registerBtn.addActionListener(e -> {
            String nombre = nameField.getText();
            String email = emailField.getText();
            String phone = phoneField.getText();
            String pass1 = new String(passwordField.getPassword());
            String pass2 = new String(confirmPasswordField.getPassword());

            if (nombre.isEmpty() || email.isEmpty() || phone.isEmpty() || pass1.isEmpty() || pass2.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (!pass1.equals(pass2)) {
                JOptionPane.showMessageDialog(this, "Las contrase�as no coinciden", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                try {
                    FileWriter fw = new FileWriter("usuarios.txt", true); // modo append
                    fw.write(email + "," + phone + "," + nombre + "," + pass1 + "\n");
                    fw.close();
                    JOptionPane.showMessageDialog(this, "�Registro exitoso!");
                    new LoginFrame();
                    dispose();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(this, "Error al guardar usuario");
                }
            }
        });

        backBtn.addActionListener(e -> {
            new LoginFrame();
            dispose();
        });

        setVisible(true);
    }
}
