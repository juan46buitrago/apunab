// DashboardFrame.java - Versi�n redise�ada dark mode con secciones completas
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class DashboardFrame extends JFrame {

    private String nombre;
    private int puntos;
    private JLabel puntosLabel;
    private JPanel mainPanel;
    private java.util.List<String> eventosAsistidos = new ArrayList<>();

    public DashboardFrame(String nombreUsuario) {
        this.nombre = nombreUsuario;
        this.puntos = 8000;

        setTitle("Apunab - Dashboard");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel sidebar = new JPanel();
        sidebar.setBackground(new Color(20, 20, 35));
        sidebar.setPreferredSize(new Dimension(180, 600));
        sidebar.setLayout(new GridLayout(6, 1, 0, 10));

        String[] opciones = {"Inicio", "Eventos", "Ranking", "Estad�sticas", "Perfil", "Cerrar sesi�n"};
        for (String op : opciones) {
            JButton btn = new JButton(op);
            btn.setFocusPainted(false);
            btn.setForeground(Color.WHITE);
            btn.setBackground(new Color(30, 30, 50));
            btn.setFont(new Font("SansSerif", Font.BOLD, 14));
            btn.setBorderPainted(false);
            sidebar.add(btn);
            btn.addActionListener(e -> cambiarVista(op));
        }

        mainPanel = new JPanel();
        mainPanel.setBackground(new Color(15, 15, 25));
        mainPanel.setLayout(null);

        add(sidebar, BorderLayout.WEST);
        add(mainPanel, BorderLayout.CENTER);

        cambiarVista("Inicio");

        setVisible(true);
    }

    private void cambiarVista(String seccion) {
        mainPanel.removeAll();
        mainPanel.setBackground(new Color(15, 15, 25));

        switch (seccion) {
            case "Inicio":
                JLabel saludo = new JLabel("Bienvenido, " + nombre);
                saludo.setFont(new Font("SansSerif", Font.BOLD, 22));
                saludo.setForeground(Color.WHITE);
                saludo.setBounds(30, 30, 400, 30);
                mainPanel.add(saludo);

                JLabel noticias = new JLabel("Noticias recientes de APUNAB");
                noticias.setForeground(Color.LIGHT_GRAY);
                noticias.setBounds(30, 80, 400, 20);
                mainPanel.add(noticias);

                JTextArea noticiasBox = new JTextArea("- �Nuevo torneo acad�mico disponible!\n- Evento 'Retos y Tecnolog�a' pr�ximo lunes\n- Ranking actualizado esta semana");
                noticiasBox.setBounds(30, 110, 400, 80);
                noticiasBox.setEditable(false);
                noticiasBox.setBackground(new Color(25, 25, 40));
                noticiasBox.setForeground(Color.WHITE);
                noticiasBox.setFont(new Font("SansSerif", Font.PLAIN, 13));
                mainPanel.add(noticiasBox);

                JLabel progreso = new JLabel("Progreso de asistencia");
                progreso.setForeground(Color.LIGHT_GRAY);
                progreso.setBounds(30, 210, 300, 20);
                mainPanel.add(progreso);

                JTextArea asistencias = new JTextArea();
                asistencias.setBounds(30, 240, 400, 150);
                asistencias.setEditable(false);
                asistencias.setBackground(new Color(25, 25, 40));
                asistencias.setForeground(Color.GREEN);
                asistencias.setFont(new Font("SansSerif", Font.PLAIN, 13));
                if (eventosAsistidos.isEmpty()) {
                    asistencias.setText("A�n no has asistido a ning�n evento.");
                } else {
                    for (String ev : eventosAsistidos) {
                        asistencias.append("? " + ev + "\n");
                    }
                }
                mainPanel.add(asistencias);
                break;

            case "Eventos":
                JLabel eventosTitle = new JLabel("Eventos disponibles");
                eventosTitle.setFont(new Font("SansSerif", Font.BOLD, 18));
                eventosTitle.setForeground(Color.WHITE);
                eventosTitle.setBounds(30, 30, 400, 30);
                mainPanel.add(eventosTitle);

                String[] eventos = {"Torneo de f�tbol universitario", "Conferencia de innovaci�n", "Festival de m�sica UNAB"};
                JList<String> listaEventos = new JList<>(eventos);
                listaEventos.setBackground(new Color(25, 25, 40));
                listaEventos.setForeground(Color.WHITE);
                JScrollPane scrollEventos = new JScrollPane(listaEventos);
                scrollEventos.setBounds(30, 70, 400, 200);
                mainPanel.add(scrollEventos);

                JButton asistirBtn = new JButton("Registrar asistencia");
                asistirBtn.setBounds(450, 70, 180, 30);
                asistirBtn.setBackground(new Color(10, 102, 255));
                asistirBtn.setForeground(Color.WHITE);
                mainPanel.add(asistirBtn);

                asistirBtn.addActionListener(e -> {
                    String seleccionado = listaEventos.getSelectedValue();
                    if (seleccionado != null) {
                        eventosAsistidos.add(seleccionado);
                        puntos += 1000;
                        JOptionPane.showMessageDialog(this, "Asistencia registrada a: " + seleccionado + "\n+1000 APUNAB");
                        cambiarVista("Inicio");
                    } else {
                        JOptionPane.showMessageDialog(this, "Selecciona un evento primero.");
                    }
                });
                break;

            case "Ranking":
                JLabel rankingTitle = new JLabel("Ranking estudiantil");
                rankingTitle.setFont(new Font("SansSerif", Font.BOLD, 18));
                rankingTitle.setForeground(Color.WHITE);
                rankingTitle.setBounds(30, 30, 400, 30);
                mainPanel.add(rankingTitle);

                String[] columnas = {"Nombre", "APUNAB"};
                Object[][] datos = {
                    {"Carla L�pez", 92000},
                    {"Luis G�mez", 86000},
                    {"Ana Rivera", 85000},
                    {nombre, puntos}
                };
                JTable tabla = new JTable(datos, columnas);
                tabla.setBackground(new Color(30, 30, 50));
                tabla.setForeground(Color.WHITE);
                tabla.setFont(new Font("SansSerif", Font.PLAIN, 13));
                JScrollPane scrollTabla = new JScrollPane(tabla);
                scrollTabla.setBounds(30, 70, 400, 150);
                mainPanel.add(scrollTabla);
                break;

            case "Estad�sticas":
                JLabel stats = new JLabel("Resumen de actividad");
                stats.setFont(new Font("SansSerif", Font.BOLD, 18));
                stats.setForeground(Color.WHITE);
                stats.setBounds(30, 30, 300, 30);
                mainPanel.add(stats);

                JTextArea info = new JTextArea();
                info.setBounds(30, 70, 400, 120);
                info.setEditable(false);
                info.setFont(new Font("SansSerif", Font.PLAIN, 13));
                info.setBackground(new Color(25, 25, 40));
                info.setForeground(Color.LIGHT_GRAY);
                info.setText("Eventos asistidos: " + eventosAsistidos.size() +
                        "\nPuntos acumulados: " + puntos +
                        "\nMeta: 100000\nFaltan: " + (100000 - puntos) + " APUNAB");
                mainPanel.add(info);
                break;

            case "Perfil":
                JLabel perfil = new JLabel("Mi perfil");
                perfil.setFont(new Font("SansSerif", Font.BOLD, 18));
                perfil.setForeground(Color.WHITE);
                perfil.setBounds(30, 30, 300, 30);
                mainPanel.add(perfil);

                JLabel nombreLbl = new JLabel("Nombre: " + nombre);
                nombreLbl.setBounds(30, 80, 400, 25);
                nombreLbl.setForeground(Color.LIGHT_GRAY);
                JLabel correoLbl = new JLabel("Correo: estudiante@unab.edu.co");
                correoLbl.setBounds(30, 110, 400, 25);
                correoLbl.setForeground(Color.LIGHT_GRAY);
                JLabel carreraLbl = new JLabel("Carrera: Ingenier�a de Sistemas");
                carreraLbl.setBounds(30, 140, 400, 25);
                carreraLbl.setForeground(Color.LIGHT_GRAY);
                mainPanel.add(nombreLbl);
                mainPanel.add(correoLbl);
                mainPanel.add(carreraLbl);
                break;

            case "Cerrar sesi�n":
                new LoginFrame();
                dispose();
                return;
        }

        mainPanel.repaint();
        mainPanel.revalidate();
    }
}
