
// DashboardFrame.java (actualizado con meta de 100000 APUNAB)
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class DashboardFrame extends JFrame {

    private String nombre;
    private int puntos;
    private JLabel puntosLabel;
    private DefaultListModel<String> eventosModel;

    public DashboardFrame(String nombreUsuario) {
        this.nombre = nombreUsuario;
        this.puntos = cargarPuntos();

        setTitle("Apunab - Dashboard");
        setSize(950, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel sidebar = new JPanel();
        sidebar.setBackground(new Color(30, 30, 60));
        sidebar.setPreferredSize(new Dimension(180, 600));
        sidebar.setLayout(new GridLayout(6, 1, 0, 10));

        String[] opciones = {"Inicio", "Eventos", "Ranking", "Estad�sticas", "Perfil", "Cerrar sesi�n"};
        for (String op : opciones) {
            JButton btn = new JButton(op);
            btn.setFocusPainted(false);
            btn.setForeground(Color.WHITE);
            btn.setBackground(new Color(40, 40, 80));
            btn.setBorderPainted(false);
            sidebar.add(btn);

            if (op.equals("Cerrar sesi�n")) {
                btn.addActionListener(e -> {
                    new LoginFrame();
                    dispose();
                });
            }
        }

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setLayout(null);

        JLabel saludo = new JLabel("�Bienvenido, " + nombre + "!");
        saludo.setFont(new Font("SansSerif", Font.BOLD, 22));
        saludo.setBounds(30, 30, 400, 30);
        mainPanel.add(saludo);

        puntosLabel = new JLabel("Tus APUNAB acumuladas: " + puntos + " / 100000");
        puntosLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));
        puntosLabel.setBounds(30, 70, 300, 25);
        mainPanel.add(puntosLabel);

        JLabel eventosTitle = new JLabel("Eventos disponibles");
        eventosTitle.setFont(new Font("SansSerif", Font.BOLD, 16));
        eventosTitle.setBounds(30, 120, 200, 25);
        mainPanel.add(eventosTitle);

        eventosModel = new DefaultListModel<>();
        cargarEventos();

        JList<String> eventosList = new JList<>(eventosModel);
        JScrollPane scrollPane = new JScrollPane(eventosList);
        scrollPane.setBounds(30, 160, 400, 200);
        mainPanel.add(scrollPane);

        JButton asistirBtn = new JButton("Registrar asistencia");
        asistirBtn.setBounds(450, 160, 180, 30);
        asistirBtn.setBackground(new Color(10, 102, 255));
        asistirBtn.setForeground(Color.WHITE);
        mainPanel.add(asistirBtn);

        asistirBtn.addActionListener(e -> {
            String seleccionado = eventosList.getSelectedValue();
            if (seleccionado != null) {
                puntos += 1000;
                puntosLabel.setText("Tus APUNAB acumuladas: " + puntos + " / 100000");
                guardarPuntos(puntos);
                JOptionPane.showMessageDialog(this, "�Asistencia registrada! +1000 APUNAB");
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona un evento primero.");
            }
        });

        add(sidebar, BorderLayout.WEST);
        add(mainPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    private void cargarEventos() {
        try {
            File file = new File("eventos.txt");
            if (!file.exists()) {
                PrintWriter writer = new PrintWriter(file);
                writer.println("Torneo de f�tbol universitario");
                writer.println("Conferencia de innovaci�n");
                writer.println("Festival de m�sica UNAB");
                writer.close();
            }
            Scanner sc = new Scanner(file);
            while (sc.hasNextLine()) {
                eventosModel.addElement(sc.nextLine());
            }
            sc.close();
        } catch (IOException e) {
            eventosModel.addElement("Error al cargar eventos.");
        }
    }

    private int cargarPuntos() {
        try {
            File puntosFile = new File("progreso.txt");
            if (puntosFile.exists()) {
                Scanner sc = new Scanner(puntosFile);
                if (sc.hasNextInt()) {
                    return sc.nextInt();
                }
                sc.close();
            }
        } catch (IOException e) {
            return 0;
        }
        return 0;
    }

    private void guardarPuntos(int nuevosPuntos) {
        try {
            FileWriter fw = new FileWriter("progreso.txt");
            fw.write(String.valueOf(nuevosPuntos));
            fw.close();
        } catch (IOException e) {
            System.out.println("Error al guardar puntos");
        }
    }
}